﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TSPLibrary
{
    class Author
    {
        public int id { get; set; }
        public string author { get; set; }

        

    }
}
