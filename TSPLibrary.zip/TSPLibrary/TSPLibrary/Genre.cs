﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TSPLibrary
{
    class Genre
    {
        public String genre{get;set;}

        public Genre(String genre)
        {
            this.genre = genre;
        }
    }
}
